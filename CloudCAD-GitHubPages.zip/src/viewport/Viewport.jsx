import React from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Grid, Environment, GizmoHelper, GizmoViewport } from '@react-three/drei'
import { useCADStore } from '../store/useCADStore'

const ExtrudeGeometry = ({ feature, isSelected }) => {
  if (!feature.visible) return null;
  
  return (
    <mesh position={[0, feature.height / 2, 0]}>
      <boxGeometry args={[feature.width, feature.height, feature.depth]} />
      <meshStandardMaterial 
        color={isSelected ? "#60a5fa" : "#8b93a0"} 
        roughness={0.3} 
        metalness={0.2} 
        transparent 
        opacity={isSelected ? 0.9 : 1}
      />
      {isSelected && (
        <lineSegments>
          <edgesGeometry args={[new THREE.BoxGeometry(feature.width, feature.height, feature.depth)]} />
          <lineBasicMaterial color="#ffffff" linewidth={2} />
        </lineSegments>
      )}
    </mesh>
  )
}

export default function Viewport() {
  const { features, selectedFeatureId } = useCADStore()

  return (
    <div className="absolute inset-0 bg-gradient-to-b from-neutral-800 to-neutral-950">
      <Canvas camera={{ position: [15, 15, 15], fov: 45 }}>
        <ambientLight intensity={0.4} />
        <directionalLight position={[10, 20, 10]} intensity={1.5} castShadow />
        <directionalLight position={[-10, -20, -10]} intensity={0.5} />
        <Environment preset="city" />
        
        <Grid 
          infiniteGrid 
          fadeDistance={50} 
          sectionColor="#555" 
          cellColor="#333" 
          sectionSize={10} 
          cellSize={1} 
        />

        <group>
          {features.filter(f => f.type === 'EXTRUDE').map((feat) => (
            <ExtrudeGeometry 
              key={feat.id} 
              feature={feat} 
              isSelected={selectedFeatureId === feat.id} 
            />
          ))}
        </group>

        <OrbitControls makeDefault dampingFactor={0.1} />
        
        <GizmoHelper alignment="bottom-right" margin={[80, 80]}>
          <GizmoViewport axisColors={['#f87171', '#4ade80', '#60a5fa']} labelColor="white" />
        </GizmoHelper>
      </Canvas>
    </div>
  )
}