import React from 'react'
import { useCADStore } from '../store/useCADStore'

export default function PropertiesPanel() {
  const { features, selectedFeatureId, updateFeature, deleteFeature } = useCADStore()
  
  const selectedFeature = features.find(f => f.id === selectedFeatureId);

  if (!selectedFeature) {
    return (
      <aside className="w-72 border-l border-neutral-800 bg-neutral-900 p-4 flex flex-col z-10">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-3">Properties</h2>
        <div className="text-sm text-neutral-500 italic mt-4 text-center">
          Select a feature to edit
        </div>
      </aside>
    )
  }

  const handleChange = (e, field) => {
    const val = parseFloat(e.target.value);
    if (!isNaN(val)) {
      updateFeature(selectedFeature.id, { [field]: val });
    }
  };

  return (
    <aside className="w-72 border-l border-neutral-800 bg-neutral-900 flex flex-col z-10 shadow-[-4px_0_12px_rgba(0,0,0,0.2)]">
      <div className="p-3 border-b border-neutral-800">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-neutral-500">{selectedFeature.name} Properties</h2>
      </div>
      
      <div className="flex-1 p-4 overflow-y-auto flex flex-col gap-4">
        {selectedFeature.type === 'EXTRUDE' && (
          <>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-neutral-400">Width (X)</label>
              <input 
                type="number" 
                value={selectedFeature.width} 
                onChange={(e) => handleChange(e, 'width')}
                className="bg-neutral-950 border border-neutral-800 rounded px-2 py-1.5 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-neutral-400">Height (Y)</label>
              <input 
                type="number" 
                value={selectedFeature.height} 
                onChange={(e) => handleChange(e, 'height')}
                className="bg-neutral-950 border border-neutral-800 rounded px-2 py-1.5 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-neutral-400">Depth (Z)</label>
              <input 
                type="number" 
                value={selectedFeature.depth} 
                onChange={(e) => handleChange(e, 'depth')}
                className="bg-neutral-950 border border-neutral-800 rounded px-2 py-1.5 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>
          </>
        )}
        
        {selectedFeature.type === 'SKETCH' && (
          <div className="text-sm text-neutral-400">
            Sketch plane: Top (X-Z)<br/>
            Status: Under-constrained
          </div>
        )}
      </div>

      <div className="p-4 border-t border-neutral-800">
        <button 
          onClick={() => deleteFeature(selectedFeature.id)}
          className="w-full py-2 text-sm text-red-400 hover:text-red-300 hover:bg-red-400/10 rounded transition-colors border border-transparent hover:border-red-400/20"
        >
          Delete Feature
        </button>
      </div>
    </aside>
  )
}