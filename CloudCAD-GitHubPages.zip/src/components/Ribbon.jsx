import React from 'react'
import { Box, Pencil, Scissors, Layers, Circle, Type, Save, Undo, Redo, Share2 } from 'lucide-react'
import { useCADStore } from '../store/useCADStore'

const ToolButton = ({ icon: Icon, label, onClick, primary }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center justify-center gap-1 w-16 h-14 rounded-md transition-all ${
      primary 
        ? 'bg-blue-600/20 text-blue-400 hover:bg-blue-600/30 border border-blue-500/30' 
        : 'hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200'
    }`}
  >
    <Icon size={18} />
    <span className="text-[10px] font-medium">{label}</span>
  </button>
)

export default function Ribbon() {
  const addFeature = useCADStore(state => state.addFeature);

  return (
    <header className="h-20 border-b border-neutral-800 bg-neutral-900 flex flex-col z-10">
      <div className="flex items-center justify-between px-4 h-8 bg-neutral-950 border-b border-neutral-800">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-blue-500"></div>
          <span className="text-xs font-semibold tracking-wider text-neutral-300">CloudCAD</span>
          <span className="text-xs text-neutral-600">/</span>
          <span className="text-xs text-neutral-400">Untitled Document</span>
        </div>
        <div className="flex items-center gap-4 text-neutral-400">
          <Save size={14} className="cursor-pointer hover:text-white" />
          <Undo size={14} className="cursor-pointer hover:text-white" />
          <Redo size={14} className="cursor-pointer hover:text-white" />
          <button className="flex items-center gap-1.5 text-xs bg-blue-600 hover:bg-blue-500 text-white px-2.5 py-1 rounded">
            <Share2 size={12} /> Share
          </button>
        </div>
      </div>
      <div className="flex-1 flex items-center px-2 gap-1 overflow-x-auto">
        <div className="flex items-center gap-1 pr-4 border-r border-neutral-800">
          <ToolButton icon={Pencil} label="Sketch" primary onClick={() => addFeature({ type: 'SKETCH' })} />
        </div>
        <div className="flex items-center gap-1 px-4 border-r border-neutral-800">
          <ToolButton icon={Box} label="Extrude" onClick={() => addFeature({ type: 'EXTRUDE', width: 5, height: 5, depth: 5 })} />
          <ToolButton icon={Circle} label="Revolve" />
          <ToolButton icon={Layers} label="Sweep" />
          <ToolButton icon={Scissors} label="Cut" />
        </div>
      </div>
    </header>
  )
}