import React from 'react'
import { Eye, EyeOff, Box, Pencil } from 'lucide-react'
import { useCADStore } from '../store/useCADStore'

export default function FeatureTree() {
  const { features, selectedFeatureId, selectFeature, updateFeature } = useCADStore()

  return (
    <aside className="w-64 border-r border-neutral-800 bg-neutral-900 flex flex-col z-10 shadow-[4px_0_12px_rgba(0,0,0,0.2)]">
      <div className="p-3 border-b border-neutral-800 flex items-center justify-between">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-neutral-500">Feature Tree</h2>
      </div>
      <div className="flex-1 overflow-y-auto py-2">
        <div className="px-3 pb-2 text-xs text-neutral-600 font-medium">Origin</div>
        {features.map((feat) => {
          const isSelected = selectedFeatureId === feat.id;
          const Icon = feat.type === 'EXTRUDE' ? Box : Pencil;
          
          return (
            <div 
              key={feat.id} 
              onClick={() => selectFeature(feat.id)}
              className={`flex items-center justify-between px-3 py-1.5 cursor-pointer text-sm transition-colors ${
                isSelected 
                  ? 'bg-blue-600/20 text-blue-400 border-l-2 border-blue-500' 
                  : 'hover:bg-neutral-800 text-neutral-300 border-l-2 border-transparent'
              }`}
            >
              <div className="flex items-center gap-2">
                <Icon size={14} className={isSelected ? 'text-blue-400' : 'text-neutral-500'} />
                <span>{feat.name}</span>
              </div>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  updateFeature(feat.id, { visible: !feat.visible });
                }}
                className="text-neutral-600 hover:text-neutral-300"
              >
                {feat.visible ? <Eye size={14} /> : <EyeOff size={14} />}
              </button>
            </div>
          )
        })}
        {features.length === 0 && (
          <div className="px-4 py-8 text-center text-xs text-neutral-600 italic">
            No features yet. Create a sketch to begin.
          </div>
        )}
      </div>
    </aside>
  )
}