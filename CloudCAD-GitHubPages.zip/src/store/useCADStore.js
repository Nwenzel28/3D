import { create } from 'zustand'

export const useCADStore = create((set) => ({
  features: [
    { id: '1', type: 'SKETCH', name: 'Sketch 1', visible: true, timestamp: Date.now() - 10000 },
    { id: '2', type: 'EXTRUDE', name: 'Extrude 1', width: 10, height: 5, depth: 10, visible: true, timestamp: Date.now() }
  ],
  selectedFeatureId: '2',
  
  addFeature: (feature) => set((state) => {
    const id = Date.now().toString();
    let name = '';
    const count = state.features.filter(f => f.type === feature.type).length + 1;
    
    if (feature.type === 'EXTRUDE') name = `Extrude ${count}`;
    else if (feature.type === 'SKETCH') name = `Sketch ${count}`;
    else name = `Feature ${count}`;

    return {
      features: [...state.features, { ...feature, id, name, visible: true }],
      selectedFeatureId: id
    };
  }),
  
  selectFeature: (id) => set({ selectedFeatureId: id }),
  
  updateFeature: (id, updates) => set((state) => ({
    features: state.features.map(f => f.id === id ? { ...f, ...updates } : f)
  })),
  
  deleteFeature: (id) => set((state) => ({
    features: state.features.filter(f => f.id !== id),
    selectedFeatureId: state.selectedFeatureId === id ? null : state.selectedFeatureId
  }))
}))