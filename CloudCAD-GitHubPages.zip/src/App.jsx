import React from 'react'
import Ribbon from './components/Ribbon'
import FeatureTree from './components/FeatureTree'
import PropertiesPanel from './components/PropertiesPanel'
import Viewport from './viewport/Viewport'

export default function App() {
  return (
    <div className="flex flex-col h-screen w-screen bg-neutral-950 text-neutral-300">
      <Ribbon />
      <div className="flex flex-1 overflow-hidden">
        <FeatureTree />
        <main className="flex-1 relative flex bg-[#1a1a1a]">
          <Viewport />
        </main>
        <PropertiesPanel />
      </div>
    </div>
  )
}